﻿# -*- coding: utf-8 -*-
import log_result as res
import subject
import math

class SAR():
    list = None
    af = 0
    max_af = 0

    def __init__(self, list, af = 0.02, max_af = 0.2):
        self.list = list
        self.af = af
        self.max_af = max_af

    def calculate(self):
        list = self.list
        af = self.af
        max_af = self.max_af
        
        '''
        # Difference of High and Low
        differences = []
        for idx in range(0, len(list['현재가'])):
            differences.append(list['고가'][idx] - list['저가'][idx])
        '''
        # STDEV of differences
        stDev = self.standard_deviation(list)
        sarArr = [None] * len(list['현재가'])

        # Find first non-NA value
        beg = 1;
        for idx in range(0, len(list['현재가'])):
            if list['고가'][idx] == 0 or list['저가'][idx] == 0:
                sarArr[idx] = 0
                beg += 1
            else:
                break
            
        # Initialize values needed by the routine
        sig0 = 1
        sig1 = 0
        xpt0 = list['고가'][beg-1]
        xpt1 = 0
        af0 = af
        af1 = 0
        lmin = 0
        lmax = 0
        
        sarArr[beg - 1] = list['저가'][beg-1] - stDev;

        for idx in range(beg, len(list['현재가'])):
            # Increment signal, extreme point, and acceleration factor 
            sig1 = sig0
            xpt1 = xpt0
            af1 = af0

            # Local extreme
            lmin = min(list['저가'][idx-1], list['저가'][idx])
            lmax = max(list['고가'][idx-1], list['고가'][idx])

            #res.info('시가: ' + str(list['시가'][idx]) + ' 고가: ' + str(list['고가'][idx]) + ' 저가: ' + str(list['저가'][idx]) + ' 현재가: ' + str(list['현재가'][idx]))
            # Create signal and extreme price vectors
            if sig1 == 1:
                # Previous buy signal
                if list['저가'][idx] >= sarArr[idx-1]:
                    sig0 = 1
                else:
                    sig0 = -1    # New signal
                    res.info('상향->하향 반전, list[저가][idx] = ' + str(list['저가'][idx]) + ', sarArr[idx] = ' + str(sarArr[idx]))
                    res.info('체결시간(' + str(list['체결시간'][idx])[-6:-4] + ':' + str(list['체결시간'][idx])[-4:-2] + ':' + str(list['체결시간'][idx])[-2:] + ')')

                xpt0 = max(lmax, xpt1)  # New extreme price
            else:
                # Previous sell signal
                if list['고가'][idx] <= sarArr[idx-1]:
                    sig0 = -1
                else:
                    sig0 = 1   # New signal
                    res.info('하향->상향 반전, list[고가][idx] = ' + str(list['고가'][idx]) + ', sarArr[idx] = ' + str(sarArr[idx]))
                    res.info('체결시간(' + str(list['체결시간'][idx])[-6:-4] + ':' + str(list['체결시간'][idx])[-4:-2] + ':' + str(list['체결시간'][idx])[-2:] + ')')
                xpt0 = min(lmin, xpt1)  # New extreme price
                

            # Calculate acceleration factor (af) and stop-and-reverse (sar) vector
            
            # No signal change
            if sig0 == sig1:
                # Initial calculations 
                sarArr[idx] = sarArr[idx - 1] + (xpt1 - sarArr[idx - 1]) * af1;
                
                af0 = min(max_af, af + af1)
                
                # Current buy signal 
                if sig0 == 1:
                    if xpt0 > xpt1:
                        af0 = af0
                    else:
                        af0 = af1   # Update acceleration factor

                    if sarArr[idx] > lmin:
                        sarArr[idx] = lmin  # Determine sar value
                    else:
                        sarArr[idx] = sarArr[idx]
                    
                # Current sell signal
                else:
                    if xpt0 < xpt1:
                        af0 = af0
                    else:
                        af0 = af1   # Update acceleration factor
                    
                    if sarArr[idx] > lmax:
                        sarArr[idx] = sarArr[idx]
                    else:
                        sarArr[idx] = lmax  # Determine sar value
            else: # New signal
                af0 = af   # reset acceleration factor */
                sarArr[idx] = xpt0  # set sar value
                '''
                if sig0 == 1:
                    xpt0 = lmax
                    sarArr[idx] = lmin
                else:
                    xpt0 = lmin
                    sarArr[idx] = lmax
                '''
            #res.info('sig1:' + str(sig1) + ' / xpt1:' + str(xpt1) + ' / af1:' + str(af1) + ' / sar[idx-1]:' + str(sarArr[idx-1]) + ' / sar[idx]:' + str(sarArr[idx]))
            
            if sig0 != sig1: res.info('\n')

        return sarArr

    def standard_deviation(self, list):
        M = 0.0
        S = 0.0
        k = 1
        for idx in range(len(list['현재가'])):
            value = list['현재가'][idx]
            tmpM = M
            M += (value - tmpM) / k
            S += (value - tmpM) * (value - M)
            k += 1

        return math.sqrt(S / (k-2))
